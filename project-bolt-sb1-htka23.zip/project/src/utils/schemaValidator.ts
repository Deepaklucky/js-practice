import { SchemaData, SchemaType } from '../types'

interface ValidationRule {
  field: string
  validate: (value: any) => boolean
  message: string
  score: number
}

const commonRules: ValidationRule[] = [
  {
    field: 'name',
    validate: (value) => !!value && value.length >= 10,
    message: 'Name should be at least 10 characters long',
    score: 10
  },
  {
    field: 'description',
    validate: (value) => !!value && value.length >= 50,
    message: 'Description should be at least 50 characters long',
    score: 15
  },
  {
    field: 'url',
    validate: (value) => /^https?:\/\/.+/.test(value),
    message: 'URL should be a valid HTTP(S) URL',
    score: 10
  }
]

const typeSpecificRules: Record<SchemaType, ValidationRule[]> = {
  Article: [
    {
      field: 'author',
      validate: (value) => Array.isArray(value) && value.length > 0 && value[0].name,
      message: 'Article should have at least one author with a name',
      score: 10
    },
    {
      field: 'datePublished',
      validate: (value) => !!value && !isNaN(Date.parse(value)),
      message: 'Article should have a valid publication date',
      score: 5
    }
  ],
  // Add rules for other schema types...
}

export const validateSchema = (schema: SchemaData): {
  score: number
  issues: string[]
} => {
  let score = 100
  const issues: string[] = []

  // Validate common rules
  commonRules.forEach(rule => {
    if (!rule.validate(schema[rule.field])) {
      score -= rule.score
      issues.push(rule.message)
    }
  })

  // Validate type-specific rules
  const typeRules = typeSpecificRules[schema['@type']] || []
  typeRules.forEach(rule => {
    if (!rule.validate(schema[rule.field])) {
      score -= rule.score
      issues.push(rule.message)
    }
  })

  return {
    score: Math.max(0, score),
    issues
  }
}