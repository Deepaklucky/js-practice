import { SchemaType } from '../types'

interface ContentPattern {
  type: SchemaType
  patterns: RegExp[]
  confidence: number
}

const patterns: ContentPattern[] = [
  {
    type: 'Article',
    patterns: [
      /article|post|blog|news/i,
      /<article>|<main>/,
      /author|published|posted/i
    ],
    confidence: 0.8
  },
  {
    type: 'Product',
    patterns: [
      /price|product|buy|purchase/i,
      /\$\d+|\d+\.\d{2}/,
      /add to cart|buy now/i
    ],
    confidence: 0.9
  },
  {
    type: 'Organization',
    patterns: [
      /about us|company|team/i,
      /contact|email|phone/i,
      /founded|established/i
    ],
    confidence: 0.7
  },
  {
    type: 'Event',
    patterns: [
      /event|conference|webinar/i,
      /date:|when:|time:/i,
      /register|sign up|book/i
    ],
    confidence: 0.85
  }
]

export const analyzeContent = (content: string) => {
  const matches = patterns.map(pattern => {
    const matchCount = pattern.patterns.reduce((count, regex) => {
      return count + (regex.test(content) ? 1 : 0)
    }, 0)
    
    return {
      type: pattern.type,
      confidence: (matchCount / pattern.patterns.length) * pattern.confidence,
      matches: matchCount
    }
  })

  return matches
    .filter(match => match.confidence > 0.4)
    .sort((a, b) => b.confidence - a.confidence)
}

export const generateSuggestion = (type: SchemaType, confidence: number): string => {
  const suggestions = {
    Article: 'Content structure suggests an article with typical elements like author, date, and body text',
    Product: 'Page contains product-specific information including pricing and purchase options',
    Organization: 'Found company/organization details including contact information',
    Event: 'Detected event-related information including dates and registration details'
  }

  return suggestions[type] || 'Content structure matches this schema type'
}