import React, { createContext, useContext, useState } from 'react'
import { z } from 'zod'

interface AIConfig {
  provider: 'openai' | 'perplexity'
  apiKey: string
}

interface AIContextType {
  config: AIConfig | null
  setConfig: (config: AIConfig) => void
  isConfigured: boolean
}

const AIContext = createContext<AIContextType | undefined>(undefined)

const configSchema = z.object({
  provider: z.enum(['openai', 'perplexity']),
  apiKey: z.string().min(1)
})

export const AIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<AIConfig | null>(() => {
    const saved = localStorage.getItem('ai_config')
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        const validated = configSchema.parse(parsed)
        return validated
      } catch (e) {
        return null
      }
    }
    return null
  })

  const handleSetConfig = (newConfig: AIConfig) => {
    try {
      const validated = configSchema.parse(newConfig)
      localStorage.setItem('ai_config', JSON.stringify(validated))
      setConfig(validated)
    } catch (e) {
      console.error('Invalid AI configuration:', e)
    }
  }

  return (
    <AIContext.Provider value={{ 
      config, 
      setConfig: handleSetConfig, 
      isConfigured: !!config 
    }}>
      {children}
    </AIContext.Provider>
  )
}

export const useAI = () => {
  const context = useContext(AIContext)
  if (context === undefined) {
    throw new Error('useAI must be used within an AIProvider')
  }
  return context
}