import React, { useState } from 'react'
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react'
import { SchemaData } from '../types'

interface SchemaValidatorProps {
  schemaData: SchemaData
}

const SchemaValidator: React.FC<SchemaValidatorProps> = ({ schemaData }) => {
  const [score, setScore] = useState<number>(0)
  const [issues, setIssues] = useState<string[]>([])

  const validateSchema = () => {
    const newIssues: string[] = []
    let points = 100

    // Check required fields
    if (!schemaData.name) {
      newIssues.push('Missing name field')
      points -= 10
    }
    if (!schemaData.description) {
      newIssues.push('Missing description field')
      points -= 10
    }
    if (!schemaData.url) {
      newIssues.push('Missing URL field')
      points -= 10
    }

    // Check publisher details
    if (!schemaData.publisher.name) {
      newIssues.push('Missing publisher name')
      points -= 5
    }
    if (!schemaData.publisher.logo) {
      newIssues.push('Missing publisher logo')
      points -= 5
    }

    // Check content quality
    if (schemaData.description && schemaData.description.length < 50) {
      newIssues.push('Description is too short (min 50 characters)')
      points -= 5
    }
    if (!schemaData.image) {
      newIssues.push('Missing featured image')
      points -= 5
    }

    setScore(Math.max(0, points))
    setIssues(newIssues)
  }

  const getScoreColor = () => {
    if (score >= 80) return 'text-green-500'
    if (score >= 60) return 'text-yellow-500'
    return 'text-red-500'
  }

  const getScoreIcon = () => {
    if (score >= 80) return <CheckCircle className="w-6 h-6 text-green-500" />
    if (score >= 60) return <AlertTriangle className="w-6 h-6 text-yellow-500" />
    return <XCircle className="w-6 h-6 text-red-500" />
  }

  return (
    <div className="form-section mt-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
          Schema Validator
        </h2>
        <button
          onClick={validateSchema}
          className="btn btn-primary"
        >
          Validate Schema
        </button>
      </div>

      {score > 0 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
            <div className="flex items-center">
              {getScoreIcon()}
              <span className="ml-2 font-medium">Schema Score:</span>
            </div>
            <span className={`text-2xl font-bold ${getScoreColor()}`}>
              {score}/100
            </span>
          </div>

          {issues.length > 0 && (
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
              <h3 className="font-medium text-gray-900 dark:text-white mb-3">
                Issues to Address:
              </h3>
              <ul className="space-y-2">
                {issues.map((issue, index) => (
                  <li key={index} className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <AlertTriangle className="w-4 h-4 text-yellow-500 mr-2" />
                    {issue}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default SchemaValidator