import React, { useState, useEffect } from 'react'
import { Lightbulb, Loader, Settings } from 'lucide-react'
import { SchemaData } from '../types'
import { useAI } from '../context/AIContext'
import { createAIService } from '../services/ai'
import AIConfigModal from './AIConfigModal'
import { useAuth } from '../context/AuthContext'

interface AiSuggestionsProps {
  schemaData: SchemaData
  onApplySuggestion: (field: string, value: string) => void
}

const AiSuggestions: React.FC<AiSuggestionsProps> = ({ schemaData, onApplySuggestion }) => {
  const { user } = useAuth()
  const { config, isConfigured } = useAI()
  const [isConfigOpen, setIsConfigOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<Array<{
    field: string
    currentValue: string
    suggestedValue: string
    reason: string
  }>>([])

  const analyzeSEO = async () => {
    if (!isConfigured || !config) return
    setLoading(true)

    try {
      const aiService = createAIService(config.provider, config.apiKey)
      const { suggestions } = await aiService.optimizeSchema(schemaData)
      setSuggestions(suggestions)
    } catch (error) {
      console.error('AI analysis failed:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!user?.isPremium) {
    return (
      <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-6 text-center">
        <Lightbulb className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Premium Feature</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Upgrade to access AI-powered schema suggestions
        </p>
      </div>
    )
  }

  return (
    <div className="form-section mt-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <Lightbulb className="w-6 h-6 text-yellow-500 mr-2" />
          <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
            AI SEO Suggestions
          </h2>
        </div>
        <button
          onClick={() => setIsConfigOpen(true)}
          className="btn btn-secondary inline-flex items-center"
        >
          <Settings className="w-4 h-4 mr-2" />
          Configure AI
        </button>
      </div>

      {!isConfigured ? (
        <div className="text-center py-8">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Configure your AI provider to get schema suggestions
          </p>
          <button
            onClick={() => setIsConfigOpen(true)}
            className="btn btn-primary"
          >
            Configure AI
          </button>
        </div>
      ) : (
        <>
          <button
            onClick={analyzeSEO}
            disabled={loading}
            className="btn btn-primary inline-flex items-center mb-6"
          >
            {loading ? (
              <>
                <Loader className="animate-spin mr-2" />
                Analyzing...
              </>
            ) : (
              'Analyze Schema'
            )}
          </button>

          {suggestions.length > 0 && (
            <div className="space-y-6">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                  <h3 className="font-medium text-gray-900 dark:text-white capitalize mb-2">
                    {suggestion.field}
                  </h3>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    Current: {suggestion.currentValue || 'Not set'}
                  </div>
                  <div className="text-sm text-green-600 dark:text-green-400 mb-3">
                    Suggestion: {suggestion.suggestedValue}
                    <p className="text-gray-500 dark:text-gray-400 text-xs mt-1">
                      {suggestion.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => onApplySuggestion(suggestion.field, suggestion.suggestedValue)}
                    className="text-sm btn btn-secondary"
                  >
                    Apply Suggestion
                  </button>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      <AIConfigModal
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
      />
    </div>
  )
}

export default AiSuggestions