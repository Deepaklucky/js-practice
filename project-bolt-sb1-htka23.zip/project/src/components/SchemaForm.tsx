import React from 'react'
import { SchemaType, SchemaData, schemaTypeProperties } from '../types'
import { Plus, Minus, AlertCircle } from 'lucide-react'

interface SchemaFormProps {
  schemaType: SchemaType
  schemaData: SchemaData
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>, nestedPath?: string) => void
  handleTypeChange: (e: React.ChangeEvent<HTMLSelectElement>) => void
  setSchemaData: React.Dispatch<React.SetStateAction<SchemaData>>
}

const SchemaForm: React.FC<SchemaFormProps> = ({ 
  schemaType, 
  schemaData, 
  handleInputChange, 
  handleTypeChange,
  setSchemaData 
}) => {
  const addNestedField = (field: string) => {
    setSchemaData(prev => {
      const currentField = prev[field]
      if (Array.isArray(currentField)) {
        return {
          ...prev,
          [field]: [...currentField, { name: '', url: '' }]
        }
      }
      return {
        ...prev,
        [field]: [{ name: '', url: '' }]
      }
    })
  }

  const removeNestedField = (field: string, index: number) => {
    setSchemaData(prev => {
      const currentField = prev[field]
      if (Array.isArray(currentField)) {
        return {
          ...prev,
          [field]: currentField.filter((_, i) => i !== index)
        }
      }
      return prev
    })
  }

  const renderField = (prop: string) => {
    // Handle nested fields like author, publisher, editor
    if (['author', 'publisher', 'editor'].includes(prop) && schemaData[prop]) {
      const items = Array.isArray(schemaData[prop]) ? schemaData[prop] : [schemaData[prop]]
      
      return (
        <div className="form-group" key={prop}>
          <div className="flex items-center justify-between mb-2">
            <label className="form-label capitalize">{prop}</label>
            <button
              type="button"
              onClick={() => addNestedField(prop)}
              className="btn btn-secondary inline-flex items-center"
            >
              <Plus size={16} className="mr-1" />
              Add {prop}
            </button>
          </div>
          {items.map((item: any, index: number) => (
            <div key={index} className="nested-field mb-4 last:mb-0">
              <div className="form-group">
                <input
                  type="text"
                  placeholder="Name"
                  value={item.name || ''}
                  onChange={(e) => handleInputChange(e, `${prop}.${index}.name`)}
                  className="form-input mb-2"
                />
                <input
                  type="url"
                  placeholder="URL"
                  value={item.url || ''}
                  onChange={(e) => handleInputChange(e, `${prop}.${index}.url`)}
                  className="form-input"
                />
                {prop === 'publisher' && (
                  <input
                    type="url"
                    placeholder="Logo URL"
                    value={item.logo || ''}
                    onChange={(e) => handleInputChange(e, `${prop}.${index}.logo`)}
                    className="form-input mt-2"
                  />
                )}
              </div>
              {items.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeNestedField(prop, index)}
                  className="absolute right-0 top-0 text-red-500 hover:text-red-700"
                >
                  <Minus size={16} />
                </button>
              )}
            </div>
          ))}
        </div>
      )
    }

    // Handle array fields
    if (['keywords', 'citation', 'recipeIngredient'].includes(prop)) {
      const values = schemaData[prop] || []
      return (
        <div className="form-group" key={prop}>
          <div className="flex items-center justify-between mb-2">
            <label className="form-label capitalize">{prop}</label>
            <button
              type="button"
              onClick={() => addNestedField(prop)}
              className="btn btn-secondary inline-flex items-center"
            >
              <Plus size={16} className="mr-1" />
              Add Item
            </button>
          </div>
          {values.map((value: string, index: number) => (
            <div key={index} className="nested-field mb-4 last:mb-0">
              <input
                type="text"
                value={value}
                onChange={(e) => handleInputChange(e, `${prop}.${index}`)}
                className="form-input"
              />
              <button
                type="button"
                onClick={() => removeNestedField(prop, index)}
                className="absolute right-0 top-0 text-red-500 hover:text-red-700"
              >
                <Minus size={16} />
              </button>
            </div>
          ))}
        </div>
      )
    }

    // Handle boolean fields
    if (['isAccessibleForFree'].includes(prop)) {
      return (
        <div className="form-group" key={prop}>
          <label className="form-label capitalize flex items-center">
            <input
              type="checkbox"
              name={prop}
              checked={!!schemaData[prop]}
              onChange={(e) => handleInputChange({
                target: {
                  name: prop,
                  value: e.target.checked
                }
              } as any)}
              className="mr-2 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
            {prop.replace(/([A-Z])/g, ' $1').trim()}
          </label>
        </div>
      )
    }

    // Handle number fields
    if (['wordCount', 'commentCount'].includes(prop)) {
      return (
        <div className="form-group" key={prop}>
          <label htmlFor={prop} className="form-label capitalize">
            {prop.replace(/([A-Z])/g, ' $1').trim()}
          </label>
          <input
            type="number"
            id={prop}
            name={prop}
            value={schemaData[prop] || ''}
            onChange={handleInputChange}
            className="form-input"
          />
        </div>
      )
    }

    // Default field rendering
    return (
      <div className="form-group" key={prop}>
        <label htmlFor={prop} className="form-label capitalize">
          {prop.replace(/([A-Z])/g, ' $1').trim()}
        </label>
        {prop.includes('date') ? (
          <input
            type="datetime-local"
            id={prop}
            name={prop}
            value={schemaData[prop] || ''}
            onChange={handleInputChange}
            className="form-input"
          />
        ) : prop.includes('description') || prop.includes('articleBody') ? (
          <textarea
            id={prop}
            name={prop}
            value={schemaData[prop] || ''}
            onChange={handleInputChange}
            rows={4}
            className="form-input"
          />
        ) : (
          <input
            type={prop.includes('url') || prop.includes('image') ? 'url' : 'text'}
            id={prop}
            name={prop}
            value={schemaData[prop] || ''}
            onChange={handleInputChange}
            className="form-input"
          />
        )}
      </div>
    )
  }

  return (
    <div className="form-section">
      <div className="form-group">
        <label htmlFor="schemaType" className="form-label">Schema Type</label>
        <select
          id="schemaType"
          value={schemaType}
          onChange={handleTypeChange}
          className="form-input"
        >
          {Object.keys(schemaTypeProperties).map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      <div className="mt-8">
        {schemaTypeProperties[schemaType].map(renderField)}
      </div>
    </div>
  )
}

export default SchemaForm