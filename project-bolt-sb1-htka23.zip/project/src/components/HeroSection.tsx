import React from 'react'
import { Search } from 'lucide-react'
import UrlScanner from './UrlScanner'
import { SchemaData } from '../types'

interface HeroSectionProps {
  onScanComplete: (data: Partial<SchemaData>) => void
}

const HeroSection: React.FC<HeroSectionProps> = ({ onScanComplete }) => {
  return (
    <div className="relative bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 pt-32 pb-20">
      <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-6xl font-bold font-heading bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 mb-6">
          Your One Stop for Schema Generation
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-12">
          Generate, validate, and optimize your schema markup in seconds. 
          Boost your SEO with AI-powered suggestions.
        </p>
        
        <div className="max-w-2xl mx-auto">
          <UrlScanner onScanComplete={onScanComplete} />
        </div>
      </div>
    </div>
  )
}

export default HeroSection