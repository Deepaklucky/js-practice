import React, { useState } from 'react'
import { SchemaType, SchemaData, initialSchemaData, schemaTypeProperties } from '../types'

interface NestedSchemaFormProps {
  schemaType: SchemaType
  onSubmit: (data: SchemaData) => void
  onCancel: () => void
}

const NestedSchemaForm: React.FC<NestedSchemaFormProps> = ({ schemaType, onSubmit, onCancel }) => {
  const [nestedData, setNestedData] = useState<SchemaData>({
    ...initialSchemaData,
    '@type': schemaType,
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNestedData(prevData => ({ ...prevData, [name]: value }))
  }

  const handleSubmit = (e: React.MouseEvent) => {
    e.preventDefault()
    onSubmit(nestedData)
  }

  return (
    <div className="space-y-4">
      {schemaTypeProperties[schemaType].map(prop => (
        <div key={prop}>
          <label htmlFor={prop} className="block text-sm font-medium text-gray-700 mb-1">
            {prop.charAt(0).toUpperCase() + prop.slice(1)}
          </label>
          <input
            type="text"
            id={prop}
            name={prop}
            value={nestedData[prop] || ''}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>
      ))}
      <div className="flex justify-end space-x-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
        >
          Add Nested Schema
        </button>
      </div>
    </div>
  )
}

export default NestedSchemaForm