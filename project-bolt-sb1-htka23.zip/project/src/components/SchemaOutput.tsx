import React, { useState } from 'react'
import { SchemaType, SchemaData } from '../types'
import { Copy, Check, ExternalLink } from 'lucide-react'

interface SchemaOutputProps {
  schemaType: SchemaType
  schemaData: SchemaData
}

const SchemaOutput: React.FC<SchemaOutputProps> = ({ schemaType, schemaData }) => {
  const [copied, setCopied] = useState(false)

  const generateSchemaMarkup = () => {
    const schema: any = {
      "@context": "https://schema.org",
      "@type": schemaType,
    }

    // Process all properties
    Object.entries(schemaData).forEach(([key, value]) => {
      if (key === '@type' || !value || value === '') return
      if (key === 'additionalProperties' || key === 'nestedSchemas' || key === 'existingSchemas') return

      // Handle nested objects like author and publisher
      if (['author', 'editor'].includes(key)) {
        if (Array.isArray(value)) {
          schema[key] = value.map(item => ({
            "@type": "Person",
            ...item
          }))
        } else if (typeof value === 'object' && value.name) {
          schema[key] = {
            "@type": "Person",
            ...value
          }
        }
      }
      // Handle publisher
      else if (key === 'publisher') {
        if (value.name) {
          schema[key] = {
            "@type": "Organization",
            ...value,
            logo: value.logo ? {
              "@type": "ImageObject",
              "url": value.logo
            } : undefined
          }
        }
      }
      // Handle sourceOrganization
      else if (key === 'sourceOrganization' && typeof value === 'object' && value.name) {
        schema[key] = {
          "@type": "Organization",
          ...value
        }
      }
      // Handle speakable
      else if (key === 'speakable' && value.cssSelector) {
        schema[key] = {
          "@type": "SpeakableSpecification",
          "cssSelector": value.cssSelector
        }
      }
      // Handle array fields
      else if (Array.isArray(value)) {
        schema[key] = value.filter(item => item !== '')
      }
      // Handle boolean fields
      else if (typeof value === 'boolean') {
        schema[key] = value
      }
      // Handle regular fields
      else if (value) {
        schema[key] = value
      }
    })

    return JSON.stringify(schema, null, 2)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generateSchemaMarkup()).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const testSchema = () => {
    const schema = generateSchemaMarkup()
    const form = document.createElement('form')
    form.method = 'POST'
    form.action = 'https://search.google.com/test/rich-results'
    form.target = '_blank'
    
    const input = document.createElement('input')
    input.type = 'hidden'
    input.name = 'code_snippet'
    input.value = schema

    form.appendChild(input)
    document.body.appendChild(form)
    form.submit()
    document.body.removeChild(form)
  }

  return (
    <div className="form-section mt-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
          Generated Schema Markup
        </h2>
        <div className="space-x-3">
          <button
            onClick={copyToClipboard}
            className="btn btn-primary inline-flex items-center"
          >
            {copied ? (
              <>
                <Check size={18} className="mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy size={18} className="mr-2" />
                Copy to Clipboard
              </>
            )}
          </button>
          <button
            onClick={testSchema}
            className="btn btn-secondary inline-flex items-center"
          >
            <ExternalLink size={18} className="mr-2" />
            Test Schema
          </button>
        </div>
      </div>
      <pre className="bg-gray-50 dark:bg-gray-900 p-6 rounded-lg overflow-x-auto text-sm">
        <code>{generateSchemaMarkup()}</code>
      </pre>
    </div>
  )
}

export default SchemaOutput