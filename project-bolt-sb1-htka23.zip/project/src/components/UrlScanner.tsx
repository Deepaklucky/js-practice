import React, { useState } from 'react'
import { Search, Loader } from 'lucide-react'
import { SchemaData } from '../types'

interface UrlScannerProps {
  onScanComplete: (scannedData: Partial<SchemaData>) => void
}

const UrlScanner: React.FC<UrlScannerProps> = ({ onScanComplete }) => {
  const [url, setUrl] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')

    try {
      const response = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(url)}`)
      const data = await response.json()
      
      if (data.contents) {
        const parser = new DOMParser()
        const doc = parser.parseFromString(data.contents, 'text/html')

        const scannedData: Partial<SchemaData> = {
          url: url,
          name: doc.querySelector('title')?.textContent || '',
          headline: doc.querySelector('h1')?.textContent || '',
          description: doc.querySelector('meta[name="description"]')?.getAttribute('content') || '',
          image: doc.querySelector('meta[property="og:image"]')?.getAttribute('content') || '',
          datePublished: formatDateWithTimezone(doc.querySelector('meta[property="article:published_time"]')?.getAttribute('content')),
          dateModified: formatDateWithTimezone(doc.querySelector('meta[property="article:modified_time"]')?.getAttribute('content')),
          author: {
            name: doc.querySelector('meta[name="author"]')?.getAttribute('content') || '',
          },
          publisher: {
            name: doc.querySelector('meta[property="og:site_name"]')?.getAttribute('content') || '',
          },
        }

        // Detect existing schema markup
        const schemaScripts = doc.querySelectorAll('script[type="application/ld+json"]')
        if (schemaScripts.length > 0) {
          const existingSchemas = Array.from(schemaScripts).map(script => {
            try {
              return JSON.parse(script.textContent || '')
            } catch (e) {
              console.error('Error parsing existing schema:', e)
              return null
            }
          }).filter(schema => schema !== null)

          if (existingSchemas.length > 0) {
            scannedData.existingSchemas = existingSchemas
          }
        }

        onScanComplete(scannedData)
      } else {
        setError('Failed to fetch page content')
      }
    } catch (err) {
      setError('An error occurred while scanning the URL')
    } finally {
      setIsLoading(false)
    }
  }

  const formatDateWithTimezone = (dateString: string | null | undefined): string => {
    if (!dateString) return ''
    
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return '' // Invalid date

    // Format the date to ISO 8601 with timezone offset
    return date.toISOString()
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-8">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Scan URL for Schema Data</h2>
      <form onSubmit={handleScan} className="flex items-center">
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL to scan"
          className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          required
        />
        <button
          type="submit"
          className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          disabled={isLoading}
        >
          {isLoading ? <Loader className="animate-spin" /> : <Search />}
        </button>
      </form>
      {error && <p className="mt-2 text-red-600">{error}</p>}
    </div>
  )
}

export default UrlScanner