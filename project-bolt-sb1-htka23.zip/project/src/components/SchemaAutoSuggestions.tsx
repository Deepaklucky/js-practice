import React, { useState } from 'react'
import { Sparkles, Lock } from 'lucide-react'
import { SchemaType } from '../types'

interface SchemaAutoSuggestionsProps {
  pageContent: string
  onSelectSchema: (schemaType: SchemaType) => void
}

interface SuggestedSchema {
  type: SchemaType
  confidence: number
  reason: string
}

const SchemaAutoSuggestions: React.FC<SchemaAutoSuggestionsProps> = ({ pageContent, onSelectSchema }) => {
  const [suggestions, setSuggestions] = useState<SuggestedSchema[]>([])
  const [loading, setLoading] = useState(false)

  const analyzePage = async () => {
    setLoading(true)
    // Simulated AI analysis - In production, this would call your AI service
    const mockAnalysis: SuggestedSchema[] = [
      {
        type: 'Article',
        confidence: 0.95,
        reason: 'Page contains long-form content with author information and publication date'
      },
      {
        type: 'BreadcrumbList',
        confidence: 0.85,
        reason: 'Navigation hierarchy detected on the page'
      },
      {
        type: 'Organization',
        confidence: 0.80,
        reason: 'Company information and contact details found'
      }
    ]
    
    setTimeout(() => {
      setSuggestions(mockAnalysis)
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Sparkles className="w-6 h-6 text-yellow-500 mr-2" />
          <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
            AI Schema Suggestions
          </h2>
        </div>
        <div className="flex items-center">
          <Lock className="w-4 h-4 text-yellow-500 mr-1" />
          <span className="text-sm text-yellow-500">Premium Feature</span>
        </div>
      </div>

      <button
        onClick={analyzePage}
        disabled={loading}
        className="w-full btn btn-primary mb-6"
      >
        {loading ? 'Analyzing Page...' : 'Analyze Page Content'}
      </button>

      {suggestions.length > 0 && (
        <div className="space-y-4">
          {suggestions.map((suggestion, index) => (
            <div
              key={index}
              className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium text-gray-900 dark:text-white">
                  {suggestion.type}
                </h3>
                <span className="px-2 py-1 text-sm bg-green-100 text-green-800 rounded">
                  {(suggestion.confidence * 100).toFixed(0)}% Match
                </span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                {suggestion.reason}
              </p>
              <button
                onClick={() => onSelectSchema(suggestion.type)}
                className="text-sm btn btn-secondary"
              >
                Use This Schema
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default SchemaAutoSuggestions