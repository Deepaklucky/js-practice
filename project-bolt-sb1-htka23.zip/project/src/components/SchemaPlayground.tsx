import React, { useState } from 'react'
import { Plus, Trash2, Code, Save } from 'lucide-react'
import { SchemaData } from '../types'

interface SchemaPlaygroundProps {
  schemaData: SchemaData
  onUpdate: (data: SchemaData) => void
}

const SchemaPlayground: React.FC<SchemaPlaygroundProps> = ({ schemaData, onUpdate }) => {
  const [customFields, setCustomFields] = useState<{ key: string; value: any; type: string }[]>([])
  const [newFieldKey, setNewFieldKey] = useState('')
  const [newFieldType, setNewFieldType] = useState('string')
  const [jsonMode, setJsonMode] = useState(false)
  const [jsonError, setJsonError] = useState('')

  const fieldTypes = [
    'string',
    'number',
    'boolean',
    'array',
    'object',
    'Person',
    'Organization',
    'Place',
    'CreativeWork',
    'Thing'
  ]

  const addCustomField = () => {
    if (!newFieldKey.trim()) return

    const defaultValue = newFieldType === 'array' ? [] 
      : newFieldType === 'object' ? {} 
      : newFieldType === 'boolean' ? false 
      : newFieldType === 'number' ? 0 
      : ''

    setCustomFields([
      ...customFields,
      { key: newFieldKey, value: defaultValue, type: newFieldType }
    ])
    setNewFieldKey('')
  }

  const updateFieldValue = (index: number, value: any) => {
    const updatedFields = [...customFields]
    try {
      updatedFields[index].value = updatedFields[index].type === 'object' || updatedFields[index].type === 'array'
        ? JSON.parse(value)
        : updatedFields[index].type === 'number'
        ? Number(value)
        : updatedFields[index].type === 'boolean'
        ? value === 'true'
        : value
      setCustomFields(updatedFields)
    } catch (e) {
      console.error('Invalid JSON format')
    }
  }

  const removeField = (index: number) => {
    setCustomFields(customFields.filter((_, i) => i !== index))
  }

  const handleJsonUpdate = (jsonString: string) => {
    try {
      const parsed = JSON.parse(jsonString)
      setJsonError('')
      onUpdate({
        ...schemaData,
        ...parsed,
        additionalProperties: {
          ...schemaData.additionalProperties,
          ...customFields.reduce((acc, field) => ({
            ...acc,
            [field.key]: field.value
          }), {})
        }
      })
    } catch (e) {
      setJsonError('Invalid JSON format')
    }
  }

  const applyCustomFields = () => {
    const updatedSchema = {
      ...schemaData,
      additionalProperties: {
        ...schemaData.additionalProperties,
        ...customFields.reduce((acc, field) => ({
          ...acc,
          [field.key]: field.value
        }), {})
      }
    }
    onUpdate(updatedSchema)
  }

  return (
    <div className="form-section mt-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
          Schema Playground
        </h2>
        <button
          onClick={() => setJsonMode(!jsonMode)}
          className="btn btn-secondary inline-flex items-center"
        >
          <Code className="w-4 h-4 mr-2" />
          {jsonMode ? 'Visual Mode' : 'JSON Mode'}
        </button>
      </div>

      {jsonMode ? (
        <div className="space-y-4">
          <textarea
            className="w-full h-96 font-mono text-sm p-4 bg-gray-50 dark:bg-gray-900 rounded-lg"
            defaultValue={JSON.stringify(schemaData, null, 2)}
            onChange={(e) => handleJsonUpdate(e.target.value)}
          />
          {jsonError && (
            <p className="text-red-500 text-sm">{jsonError}</p>
          )}
        </div>
      ) : (
        <>
          <div className="flex gap-4 mb-6">
            <input
              type="text"
              value={newFieldKey}
              onChange={(e) => setNewFieldKey(e.target.value)}
              placeholder="Field name (e.g., author, rating)"
              className="flex-grow form-input"
            />
            <select
              value={newFieldType}
              onChange={(e) => setNewFieldType(e.target.value)}
              className="form-input w-48"
            >
              {fieldTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            <button
              onClick={addCustomField}
              className="btn btn-primary inline-flex items-center"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Field
            </button>
          </div>

          <div className="space-y-4 mb-6">
            {customFields.map((field, index) => (
              <div key={index} className="flex gap-4 items-start">
                <div className="flex-grow">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {field.key} ({field.type})
                  </label>
                  {field.type === 'boolean' ? (
                    <select
                      value={field.value.toString()}
                      onChange={(e) => updateFieldValue(index, e.target.value)}
                      className="form-input"
                    >
                      <option value="true">True</option>
                      <option value="false">False</option>
                    </select>
                  ) : field.type === 'object' || field.type === 'array' ? (
                    <textarea
                      value={JSON.stringify(field.value, null, 2)}
                      onChange={(e) => updateFieldValue(index, e.target.value)}
                      className="form-input font-mono"
                      rows={4}
                    />
                  ) : (
                    <input
                      type={field.type === 'number' ? 'number' : 'text'}
                      value={field.value}
                      onChange={(e) => updateFieldValue(index, e.target.value)}
                      className="form-input"
                    />
                  )}
                </div>
                <button
                  onClick={() => removeField(index)}
                  className="btn btn-danger mt-6"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {customFields.length > 0 && (
            <button
              onClick={applyCustomFields}
              className="btn btn-primary inline-flex items-center"
            >
              <Save className="w-4 h-4 mr-2" />
              Apply Custom Fields
            </button>
          )}
        </>
      )}
    </div>
  )
}

export default SchemaPlayground