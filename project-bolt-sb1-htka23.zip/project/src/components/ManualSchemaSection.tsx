import React from 'react'
import { Edit } from 'lucide-react'
import SchemaForm from './SchemaForm'
import { SchemaType, SchemaData } from '../types'

interface ManualSchemaSectionProps {
  schemaType: SchemaType
  schemaData: SchemaData
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>, nestedPath?: string) => void
  handleTypeChange: (e: React.ChangeEvent<HTMLSelectElement>) => void
  setSchemaData: React.Dispatch<React.SetStateAction<SchemaData>>
}

const ManualSchemaSection: React.FC<ManualSchemaSectionProps> = ({
  schemaType,
  schemaData,
  handleInputChange,
  handleTypeChange,
  setSchemaData
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8">
      <div className="flex items-center mb-6">
        <Edit className="w-6 h-6 text-indigo-500 mr-2" />
        <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
          Manual Schema Generation
        </h2>
      </div>

      <SchemaForm
        schemaType={schemaType}
        schemaData={schemaData}
        handleInputChange={handleInputChange}
        handleTypeChange={handleTypeChange}
        setSchemaData={setSchemaData}
      />
    </div>
  )
}

export default ManualSchemaSection