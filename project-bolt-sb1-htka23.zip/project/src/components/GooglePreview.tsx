import React from 'react'
import { SchemaType, SchemaData } from '../types'

interface GooglePreviewProps {
  schemaType: SchemaType
  schemaData: SchemaData
}

const GooglePreview: React.FC<GooglePreviewProps> = ({ schemaType, schemaData }) => {
  const renderPreview = () => {
    switch (schemaType) {
      case 'Article':
      case 'NewsArticle':
      case 'BlogPosting':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.headline || schemaData.name}</h3>
            <div className="text-sm text-gray-600 mb-2">
              {schemaData.datePublished && new Date(schemaData.datePublished).toLocaleDateString()} - {schemaData.author.name}
            </div>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
          </div>
        )
      case 'Product':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <div className="flex items-center mb-2">
              <span className="text-orange-400 mr-1">★★★★☆</span>
              <span className="text-sm text-gray-600">Rating: {schemaData.additionalProperties.aggregateRating || '4.5'}</span>
            </div>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            {schemaData.offers?.price && (
              <div className="text-sm text-gray-600 mt-1">Price: {schemaData.offers.priceCurrency}{schemaData.offers.price}</div>
            )}
          </div>
        )
      case 'Event':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <div className="text-sm text-gray-600 mb-2">
              {schemaData.startDate && new Date(schemaData.startDate).toLocaleString()} - 
              {schemaData.endDate && new Date(schemaData.endDate).toLocaleString()}
            </div>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            {schemaData.location?.name && (
              <div className="text-sm text-gray-600 mt-1">Location: {schemaData.location.name}</div>
            )}
          </div>
        )
      case 'Recipe':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <div className="text-sm text-gray-600 mb-2">
              Cook Time: {schemaData.cookTime}
            </div>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            <div className="text-sm text-gray-600 mt-1">Ingredients: {schemaData.recipeIngredient?.length || 0}</div>
          </div>
        )
      case 'JobPosting':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <div className="text-sm text-gray-600 mb-2">
              {schemaData.hiringOrganization?.name} - {schemaData.jobLocation?.addressLocality}, {schemaData.jobLocation?.addressRegion}
            </div>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            {schemaData.baseSalary?.value?.minValue && schemaData.baseSalary?.value?.maxValue && (
              <div className="text-sm text-gray-600 mt-1">
                Salary: {schemaData.baseSalary.currency}{schemaData.baseSalary.value.minValue} - {schemaData.baseSalary.value.maxValue} per {schemaData.baseSalary.value.unitText || 'year'}
              </div>
            )}
          </div>
        )
      case 'FAQPage':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            <div className="text-sm text-gray-600 mt-1">FAQs: {schemaData.mainEntity?.length || 0}</div>
          </div>
        )
      case 'HowTo':
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
            <div className="text-sm text-gray-600 mt-1">Steps: {schemaData.step?.length || 0}</div>
          </div>
        )
      default:
        return (
          <div className="max-w-2xl">
            <div className="text-sm text-green-700 mb-1">{schemaData.url}</div>
            <h3 className="text-xl text-blue-700 font-medium mb-1">{schemaData.name}</h3>
            <p className="text-sm text-gray-800">{schemaData.description}</p>
          </div>
        )
    }
  }

  return (
    <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Google Search Preview</h2>
      <div className="border border-gray-300 p-4 rounded-md">
        {renderPreview()}
      </div>
    </div>
  )
}

export default GooglePreview