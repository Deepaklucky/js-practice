import React, { useState } from 'react'
import { X, Key } from 'lucide-react'
import { useAI } from '../context/AIContext'

interface AIConfigModalProps {
  isOpen: boolean
  onClose: () => void
}

const AIConfigModal: React.FC<AIConfigModalProps> = ({ isOpen, onClose }) => {
  const { config, setConfig } = useAI()
  const [provider, setProvider] = useState(config?.provider || 'openai')
  const [apiKey, setApiKey] = useState(config?.apiKey || '')
  const [error, setError] = useState('')

  if (!isOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    try {
      setConfig({ provider, apiKey })
      onClose()
    } catch (err) {
      setError('Invalid configuration')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center mb-6">
          <Key className="w-6 h-6 text-indigo-500 mr-2" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            AI Configuration
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              AI Provider
            </label>
            <select
              value={provider}
              onChange={(e) => setProvider(e.target.value as 'openai' | 'perplexity')}
              className="form-input"
            >
              <option value="openai">OpenAI</option>
              <option value="perplexity">Perplexity</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              API Key
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="form-input"
              placeholder="Enter your API key"
              required
            />
          </div>

          {error && (
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          )}

          <button
            type="submit"
            className="w-full btn btn-primary"
          >
            Save Configuration
          </button>

          <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
            Your API key is stored securely in your browser's local storage.
          </p>
        </form>
      </div>
    </div>
  )
}

export default AIConfigModal