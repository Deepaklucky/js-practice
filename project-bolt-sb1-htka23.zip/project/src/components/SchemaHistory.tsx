import React from 'react'
import { History, Star } from 'lucide-react'
import { SchemaData } from '../types'

interface SchemaHistoryProps {
  onLoadSchema: (schema: SchemaData) => void
}

const SchemaHistory: React.FC<SchemaHistoryProps> = ({ onLoadSchema }) => {
  const templates = [
    {
      name: 'Blog Post Template',
      type: 'BlogPosting',
      icon: '📝',
      isPremium: false
    },
    {
      name: 'E-commerce Product',
      type: 'Product',
      icon: '🛍️',
      isPremium: true
    },
    {
      name: 'Local Business',
      type: 'LocalBusiness',
      icon: '🏪',
      isPremium: true
    }
  ]

  const loadTemplate = (type: string) => {
    const template: SchemaData = {
      '@type': type as SchemaType,
      name: '',
      description: '',
      url: '',
      author: [{ name: '', url: '' }],
      publisher: {
        name: '',
        logo: '',
        url: '',
        sameAs: []
      },
      additionalProperties: {}
    }
    onLoadSchema(template)
  }

  return (
    <div className="form-section mt-8">
      <div className="flex items-center mb-6">
        <History className="w-6 h-6 text-indigo-500 mr-2" />
        <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white">
          Templates & History
        </h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template, index) => (
          <div
            key={index}
            className="relative bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
          >
            {template.isPremium && (
              <div className="absolute top-2 right-2">
                <Star className="w-5 h-5 text-yellow-500" fill="currentColor" />
              </div>
            )}
            <div className="text-2xl mb-2">{template.icon}</div>
            <h3 className="font-medium text-gray-900 dark:text-white mb-1">
              {template.name}
            </h3>
            <button
              onClick={() => loadTemplate(template.type)}
              className="mt-2 text-sm btn btn-secondary w-full"
              disabled={template.isPremium}
            >
              {template.isPremium ? 'Premium Template' : 'Use Template'}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default SchemaHistory