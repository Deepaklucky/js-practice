import OpenAI from 'openai'
import axios from 'axios'
import { SchemaType, SchemaData } from '../types'

interface AIService {
  analyzeContent: (content: string) => Promise<{
    suggestedSchemas: Array<{
      type: SchemaType
      confidence: number
      reason: string
    }>
  }>
  generateSchema: (type: SchemaType, content: string) => Promise<Partial<SchemaData>>
  optimizeSchema: (schema: SchemaData) => Promise<{
    suggestions: Array<{
      field: string
      currentValue: string
      suggestedValue: string
      reason: string
    }>
  }>
}

class OpenAIService implements AIService {
  private client: OpenAI

  constructor(apiKey: string) {
    this.client = new OpenAI({ apiKey })
  }

  async analyzeContent(content: string) {
    const response = await this.client.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an expert in Schema.org markup and SEO optimization. Analyze content and suggest appropriate schema types.'
        },
        {
          role: 'user',
          content: `Analyze this content and suggest appropriate schema types with confidence scores and reasons:\n\n${content}`
        }
      ]
    })

    const suggestions = this.parseAIResponse<Array<{
      type: SchemaType
      confidence: number
      reason: string
    }>>(response.choices[0].message.content || '[]')

    return { suggestedSchemas: suggestions }
  }

  async generateSchema(type: SchemaType, content: string) {
    const response = await this.client.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'Generate a complete and valid Schema.org markup based on the content.'
        },
        {
          role: 'user',
          content: `Generate a ${type} schema for this content:\n\n${content}`
        }
      ]
    })

    return this.parseAIResponse<Partial<SchemaData>>(response.choices[0].message.content || '{}')
  }

  async optimizeSchema(schema: SchemaData) {
    const response = await this.client.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'Analyze and suggest improvements for Schema.org markup to enhance SEO.'
        },
        {
          role: 'user',
          content: `Suggest improvements for this schema:\n\n${JSON.stringify(schema, null, 2)}`
        }
      ]
    })

    const suggestions = this.parseAIResponse<Array<{
      field: string
      currentValue: string
      suggestedValue: string
      reason: string
    }>>(response.choices[0].message.content || '[]')

    return { suggestions }
  }

  private parseAIResponse<T>(content: string): T {
    try {
      return JSON.parse(content)
    } catch (e) {
      console.error('Error parsing AI response:', e)
      return {} as T
    }
  }
}

class PerplexityService implements AIService {
  private apiKey: string
  private baseURL = 'https://api.perplexity.ai'

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async analyzeContent(content: string) {
    const response = await axios.post(
      `${this.baseURL}/chat/completions`,
      {
        model: 'mixtral-8x7b-instruct',
        messages: [
          {
            role: 'system',
            content: 'You are an expert in Schema.org markup and SEO optimization.'
          },
          {
            role: 'user',
            content: `Analyze this content and suggest appropriate schema types with confidence scores and reasons:\n\n${content}`
          }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    )

    const suggestions = this.parseAIResponse<Array<{
      type: SchemaType
      confidence: number
      reason: string
    }>>(response.data.choices[0].message.content || '[]')

    return { suggestedSchemas: suggestions }
  }

  async generateSchema(type: SchemaType, content: string) {
    const response = await axios.post(
      `${this.baseURL}/chat/completions`,
      {
        model: 'mixtral-8x7b-instruct',
        messages: [
          {
            role: 'system',
            content: 'Generate a complete and valid Schema.org markup based on the content.'
          },
          {
            role: 'user',
            content: `Generate a ${type} schema for this content:\n\n${content}`
          }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    )

    return this.parseAIResponse<Partial<SchemaData>>(response.data.choices[0].message.content || '{}')
  }

  async optimizeSchema(schema: SchemaData) {
    const response = await axios.post(
      `${this.baseURL}/chat/completions`,
      {
        model: 'mixtral-8x7b-instruct',
        messages: [
          {
            role: 'system',
            content: 'Analyze and suggest improvements for Schema.org markup to enhance SEO.'
          },
          {
            role: 'user',
            content: `Suggest improvements for this schema:\n\n${JSON.stringify(schema, null, 2)}`
          }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    )

    const suggestions = this.parseAIResponse<Array<{
      field: string
      currentValue: string
      suggestedValue: string
      reason: string
    }>>(response.data.choices[0].message.content || '[]')

    return { suggestions }
  }

  private parseAIResponse<T>(content: string): T {
    try {
      return JSON.parse(content)
    } catch (e) {
      console.error('Error parsing AI response:', e)
      return {} as T
    }
  }
}

export const createAIService = (provider: 'openai' | 'perplexity', apiKey: string): AIService => {
  switch (provider) {
    case 'openai':
      return new OpenAIService(apiKey)
    case 'perplexity':
      return new PerplexityService(apiKey)
    default:
      throw new Error('Unsupported AI provider')
  }
}