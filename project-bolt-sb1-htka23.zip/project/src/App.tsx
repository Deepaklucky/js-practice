import React, { useState } from 'react'
import { BrowserRouter as Router } from 'react-router-dom'
import Header from './components/Header'
import HeroSection from './components/HeroSection'
import ManualSchemaSection from './components/ManualSchemaSection'
import SchemaAutoSuggestions from './components/SchemaAutoSuggestions'
import SchemaPlayground from './components/SchemaPlayground'
import SchemaValidator from './components/SchemaValidator'
import GooglePreview from './components/GooglePreview'
import AiSuggestions from './components/AiSuggestions'
import SchemaOutput from './components/SchemaOutput'
import { ThemeProvider } from './context/ThemeContext'
import { AuthProvider } from './context/AuthContext'
import { AIProvider } from './context/AIContext'
import { SchemaType, SchemaData, initialSchemaData } from './types'

const App: React.FC = () => {
  const [schemaType, setSchemaType] = useState<SchemaType>('Article')
  const [schemaData, setSchemaData] = useState<SchemaData>(initialSchemaData)

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSchemaType(e.target.value as SchemaType)
    setSchemaData({
      ...initialSchemaData,
      '@type': e.target.value as SchemaType
    })
  }

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
    nestedPath?: string
  ) => {
    const { name, value } = e.target
    
    if (nestedPath) {
      const [field, index, prop] = nestedPath.split('.')
      setSchemaData(prev => {
        const updatedField = [...prev[field]]
        updatedField[Number(index)] = {
          ...updatedField[Number(index)],
          [prop]: value
        }
        return {
          ...prev,
          [field]: updatedField
        }
      })
    } else {
      setSchemaData(prev => ({
        ...prev,
        [name]: value
      }))
    }
  }

  const handleScanComplete = (scannedData: Partial<SchemaData>) => {
    setSchemaData(prev => ({
      ...prev,
      ...scannedData
    }))
  }

  return (
    <Router>
      <AuthProvider>
        <AIProvider>
          <ThemeProvider>
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
              <Header />
              <main className="container mx-auto px-4 py-8">
                <HeroSection onScanComplete={handleScanComplete} />
                
                <ManualSchemaSection
                  schemaType={schemaType}
                  schemaData={schemaData}
                  handleInputChange={handleInputChange}
                  handleTypeChange={handleTypeChange}
                  setSchemaData={setSchemaData}
                />

                <SchemaAutoSuggestions
                  pageContent={schemaData.description || ''}
                  onSelectSchema={(type) => setSchemaType(type)}
                />

                <SchemaPlayground
                  schemaData={schemaData}
                  onUpdate={setSchemaData}
                />

                <SchemaValidator schemaData={schemaData} />
                
                <GooglePreview
                  schemaType={schemaType}
                  schemaData={schemaData}
                />

                <AiSuggestions
                  schemaData={schemaData}
                  onApplySuggestion={(field, value) => {
                    setSchemaData(prev => ({
                      ...prev,
                      [field]: value
                    }))
                  }}
                />

                <SchemaOutput
                  schemaType={schemaType}
                  schemaData={schemaData}
                />
              </main>
            </div>
          </ThemeProvider>
        </AIProvider>
      </AuthProvider>
    </Router>
  )
}

export default App