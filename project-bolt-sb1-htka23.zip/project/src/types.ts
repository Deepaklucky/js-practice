export type SchemaType =
  | 'Article'
  | 'NewsArticle'
  | 'BlogPosting'
  | 'Book'
  | 'Event'
  | 'FAQPage'
  | 'HowTo'
  | 'JobPosting'
  | 'LocalBusiness'
  | 'Movie'
  | 'Product'
  | 'Recipe'
  | 'Review'
  | 'Organization'
  | 'Person'
  | 'WebSite'
  | 'Course'
  | 'VideoObject'

export interface Author {
  name: string
  url?: string
  email?: string
  image?: string
  sameAs?: string[]
}

export interface Publisher {
  name: string
  logo?: string
  url?: string
  sameAs?: string[]
  address?: {
    streetAddress: string
    addressLocality: string
    addressRegion: string
    postalCode: string
    addressCountry: string
  }
}

export interface SchemaData {
  '@type': SchemaType
  name: string
  headline?: string
  alternativeHeadline?: string
  description: string
  articleBody?: string
  url: string
  image?: string
  datePublished?: string
  dateModified?: string
  author: Author[] | Author
  publisher: Publisher
  keywords?: string[]
  inLanguage?: string
  isAccessibleForFree?: boolean
  hasPart?: any[]
  mainEntityOfPage?: string
  speakable?: {
    cssSelector: string[]
  }
  // Article-specific fields
  wordCount?: number
  articleSection?: string
  // NewsArticle-specific fields
  dateline?: string
  printEdition?: string
  printPage?: string
  // BlogPosting-specific fields
  commentCount?: number
  // Product-specific fields
  brand?: string
  sku?: string
  mpn?: string
  gtin?: string
  review?: any[]
  aggregateRating?: {
    ratingValue: number
    reviewCount: number
  }
  offers?: {
    price: number
    priceCurrency: string
    availability: string
    validFrom?: string
  }
  // Event-specific fields
  startDate?: string
  endDate?: string
  location?: {
    name: string
    address: string
  }
  performer?: string[]
  // Course-specific fields
  provider?: string
  courseCode?: string
  coursePrerequisites?: string[]
  educationalLevel?: string
  // Video-specific fields
  duration?: string
  thumbnailUrl?: string
  uploadDate?: string
  contentUrl?: string
  embedUrl?: string
  // Common fields for all types
  award?: string
  editor?: Author[]
  genre?: string
  license?: string
  sourceOrganization?: {
    name: string
    url?: string
  }
  citation?: string[]
  // Validation and metadata
  additionalProperties: { [key: string]: any }
  nestedSchemas?: SchemaData[]
  existingSchemas?: any[]
}

export const initialSchemaData: SchemaData = {
  '@type': 'Article',
  name: '',
  description: '',
  url: '',
  author: [{ name: '', url: '' }],
  publisher: { name: '', logo: '' },
  additionalProperties: {},
}

export const schemaTypeProperties: Record<SchemaType, string[]> = {
  Article: [
    'name',
    'headline',
    'alternativeHeadline',
    'description',
    'articleBody',
    'url',
    'image',
    'datePublished',
    'dateModified',
    'author',
    'publisher',
    'keywords',
    'inLanguage',
    'wordCount',
    'articleSection',
    'isAccessibleForFree',
    'mainEntityOfPage'
  ],
  NewsArticle: [
    'name',
    'headline',
    'description',
    'articleBody',
    'url',
    'image',
    'datePublished',
    'dateModified',
    'author',
    'publisher',
    'keywords',
    'dateline',
    'printEdition',
    'printPage'
  ],
  BlogPosting: [
    'name',
    'headline',
    'description',
    'articleBody',
    'url',
    'image',
    'datePublished',
    'dateModified',
    'author',
    'publisher',
    'keywords',
    'commentCount'
  ],
  Book: [
    'name',
    'description',
    'author',
    'url',
    'image',
    'isbn',
    'publisher',
    'datePublished',
    'inLanguage',
    'genre'
  ],
  Event: [
    'name',
    'description',
    'startDate',
    'endDate',
    'location',
    'performer',
    'url',
    'image'
  ],
  FAQPage: [
    'name',
    'description',
    'mainEntity',
    'url'
  ],
  HowTo: [
    'name',
    'description',
    'step',
    'tool',
    'supply',
    'url',
    'image',
    'totalTime'
  ],
  JobPosting: [
    'name',
    'description',
    'datePosted',
    'validThrough',
    'employmentType',
    'hiringOrganization',
    'jobLocation',
    'baseSalary'
  ],
  LocalBusiness: [
    'name',
    'description',
    'url',
    'image',
    'address',
    'telephone',
    'openingHours',
    'priceRange'
  ],
  Movie: [
    'name',
    'description',
    'director',
    'actor',
    'dateCreated',
    'duration',
    'url',
    'image'
  ],
  Product: [
    'name',
    'description',
    'brand',
    'sku',
    'mpn',
    'gtin',
    'url',
    'image',
    'offers',
    'review',
    'aggregateRating'
  ],
  Recipe: [
    'name',
    'description',
    'recipeIngredient',
    'recipeInstructions',
    'cookTime',
    'prepTime',
    'totalTime',
    'url',
    'image'
  ],
  Review: [
    'name',
    'description',
    'reviewRating',
    'itemReviewed',
    'author',
    'datePublished',
    'url'
  ],
  Organization: [
    'name',
    'description',
    'url',
    'logo',
    'address',
    'contactPoint',
    'sameAs'
  ],
  Person: [
    'name',
    'description',
    'image',
    'email',
    'url',
    'jobTitle',
    'worksFor',
    'sameAs'
  ],
  WebSite: [
    'name',
    'description',
    'url',
    'publisher',
    'inLanguage',
    'keywords'
  ],
  Course: [
    'name',
    'description',
    'provider',
    'courseCode',
    'coursePrerequisites',
    'educationalLevel',
    'url',
    'image'
  ],
  VideoObject: [
    'name',
    'description',
    'thumbnailUrl',
    'uploadDate',
    'duration',
    'contentUrl',
    'embedUrl',
    'url'
  ]
}